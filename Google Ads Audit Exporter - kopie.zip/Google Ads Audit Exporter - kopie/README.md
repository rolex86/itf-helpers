# Google Ads Audit Exporter v1

Read-only exporter pro interni audit Google Ads uctu. Nastroj stahuje vybrane reporty pres Google Ads API, uklada raw CSV, metadata a sestavuje jeden `audit_export.xlsx` soubor s vice listy. Ovlada se pres CLI i browser UI nad stejnym export workflow.

## Co umi

- Export pro jeden `customer_id`
- Predvolby obdobi `LAST_30_DAYS`, `LAST_90_DAYS`, `LAST_365_DAYS`
- Vlastni `date_from` / `date_to`
- Raw CSV export, metadata JSON a souhrnny XLSX
- Pokracovani exportu i pri selhani jednotliveho reportu
- Jednoduche auditni flagy pro rychlou orientaci
- Browser rozhrani pro konfiguraci a spousteni bez terminalu
- Shopping produktovy vykon a produktovy souhrn
- Read-only export Google Ads doporuceni
- Diagnostika uctu a propojenych sluzeb
- Volitelny Merchant Center modul pro feed data a produktove issue
- Volitelny GA4 modul pro landing page engagement a ecommerce funnel
- Volitelny Search Console modul pro organicke dotazy, stranky a SEO/PPC overlap
- Volitelny PageSpeed modul pro technickou diagnostiku top landing pages
- Volitelny Google Tag Manager modul pro audit tagu a diagnostiku mereni
- Multi-account discovery, mapping a sekvencni export vice kontextu

## Free-only politika

Zakladni konfigurace pocita s tim, ze aplikace ma bezet v lokalnim a neplacenem rezimu:

```yaml
cost_policy:
  free_only: true
  forbid_paid_cloud_resources: true
  allow_local_storage_only: true
```

V tehle verzi aplikace:

- nepouziva Cloud Run, Compute Engine, Cloud SQL, BigQuery ani Cloud Storage
- nepouziva placene AI API ani placene externi SaaS API
- uklada data jen lokalne do CSV, XLSX, JSON a lokalni cache
- pracuje read-only nad Google Ads API

## Bezpecnost

Tato verze je striktne read-only.

- Nepouziva zadne mutate endpointy ani mutate sluzby.
- Neprovadi create, update, remove, pause, enable ani zadne upravy bidu, budgetu, keywordu nebo reklam.
- Veskery kod je postaveny pouze na reportovacich GAQL dotazech pres `GoogleAdsService.search_stream`.

## Pozadavky

- Python 3.10+
- OAuth 2.0 pristup do Google Ads API
- Developer token
- `customer_id` uctu, ktery chcete exportovat

Instalace zavislosti:

```bash
python -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
```

## Konfigurace

1. Zkopirujte `.env.example` na `.env` a doplnte pristupy.
2. Zkopirujte `config.example.yaml` na `config.yaml` a upravte exportni nastaveni.
3. Pokud chces multi-account rezim, uprav `config.accounts.yaml` nebo si ho napln pres webovou sekci Mapping.

### `.env`

```env
GOOGLE_ADS_DEVELOPER_TOKEN=
GOOGLE_ADS_CLIENT_ID=
GOOGLE_ADS_CLIENT_SECRET=
GOOGLE_ADS_REFRESH_TOKEN=
GOOGLE_ADS_LOGIN_CUSTOMER_ID=
MERCHANT_CENTER_ACCOUNT_ID=
GOOGLE_MERCHANT_ENABLED=false
GA4_PROPERTY_ID=
GA4_ENABLED=false
GSC_SITE_URL=https://www.example.cz/
GSC_ENABLED=false
GTM_ACCOUNT_ID=
GTM_CONTAINER_ID=
GTM_ENABLED=false
PAGESPEED_API_KEY=
PAGESPEED_ENABLED=false
```

### `config.yaml`

```yaml
customer_id: "1234567890"

date_range:
  preset: "LAST_90_DAYS"
  date_from: null
  date_to: null

output:
  base_dir: "exports"
  xlsx_filename: "audit_export.xlsx"
  include_raw_csv: true
  include_metadata: true

cost_policy:
  free_only: true
  forbid_paid_cloud_resources: true
  allow_local_storage_only: true

pagespeed:
  enabled: true
  max_urls_per_export: 50
  source: "top_landing_pages_by_cost"
  strategies:
    - mobile
    - desktop
  cache_days: 30

reports:
  account: true
  account_diagnostics: true
  linked_accounts: true
  campaigns: true
  campaigns_monthly: true
  ad_groups: true
  keywords: true
  search_terms: true
  ads: true
  assets: true
  devices: true
  locations: true
  landing_pages: true
  shopping_products: true
  shopping_products_summary: true
  google_ads_recommendations: true
  merchant_products: false
  merchant_product_issues: false
  merchant_product_status_summary: false
  product_optimization: false
  product_feed_issues_with_spend: false
  product_custom_label_performance: false
  ga4_landing_pages: false
  landing_page_diagnostics: false
  ga4_ecommerce_funnel: false
  gsc_queries: false
  gsc_pages: false
  gsc_page_query: false
  gsc_opportunities: false
  pagespeed_landing_pages: false
  gtm_tags: false
  gtm_triggers: false
  gtm_variables: false
  gtm_versions: false
  measurement_diagnostics: false
  conversion_actions: true
  pmax_campaigns: true
  pmax_asset_groups: true
  change_history: true

flags:
  min_spend_micros: 100000000
  min_clicks: 50
  target_cpa_micros: null
  target_roas: null
  low_ctr_threshold: 0.01
```

### `config.accounts.yaml`

```yaml
account_contexts:
  - key: shopid_cz
    label: "ShopID CZ"
    google_ads_customer_id: "4035172792"
    google_ads_login_customer_id: ""
    merchant_account_id: ""
    ga4_property_id: ""
    gsc_site_url: "https://www.shopid.cz/"
    gtm_account_id: ""
    gtm_container_id: ""
    pagespeed_enabled: true
    enabled: true
```

## Spusteni

### Browser UI

Spusteni lokalniho rozhrani:

```bash
python -m app.web.main
```

Nebo na Windows jednoduse dvojklikem:

```text
Spustit Google Ads Audit Exporter.bat
```

Volitelne:

```bash
python -m app.web.main --host 127.0.0.1 --port 5000
```

Pak otevri v prohlizeci:

```text
http://127.0.0.1:5000
```

V rozhrani muzes:

- vyplnit OAuth a Google Ads hodnoty
- ulozit `.env` a `config.yaml`
- spustit discovery dostupnych Ads/GA4/GSC/GTM/Merchant uctu
- vytvaret account contexty v Mappingu a ulozit je do `config.accounts.yaml`
- testovat jednotlive kontexty
- spustit export v rezimu `single account`, `selected context` nebo `all enabled contexts`
- zapinat a vypinat reporty
- spustit export
- prohlizet historii exportu a stahnout XLSX
- otestovat Merchant Center pristup a vypsat dostupne Merchant ucty
- otestovat GA4 pristup a vypsat dostupne properties
- otestovat Search Console pristup a vypsat dostupne properties
- otestovat Google Tag Manager pristup a vypsat dostupne ucty a kontejnery
- nastavit PageSpeed limit URL, strategie a lokalni cache

### CLI

Zakladni spusteni:

```bash
python -m app.main --config config.yaml
```

Prepsani `customer_id` a presetu z CLI:

```bash
python -m app.main --customer-id 1234567890 --preset LAST_90_DAYS
```

Vlastni datumovy rozsah:

```bash
python -m app.main --customer-id 1234567890 --date-from 2026-01-01 --date-to 2026-05-27
```

Vybrany kontext z `config.accounts.yaml`:

```bash
python -m app.main --context-key shopid_cz
```

Vsechny aktivni kontexty:

```bash
python -m app.main --all-contexts
```

## Vystupy

Po spusteni vznikne exportni slozka:

```text
exports/
  2026-05-27_1234567890/
    audit_export.xlsx
    raw/*.csv
    metadata/*.json
```

Metadata obsahuje:

- `export_config.json`
- `account_info.json`
- `query_log.json`
- `errors.json`
- `export.log`

Discovery CSV vznikaji v:

```text
exports/_discovery/
  google_ads_customers.csv
  ga4_properties.csv
  gsc_sites.csv
  gtm_containers.csv
  merchant_accounts.csv
```

Pri multi-context exportu vznikne navic:

```text
exports/YYYY-MM-DD_multi/
  <context_key>_<customer_id>/
  _cross_account/
```

## Chovani pri chybach

- Pokud selze jednotlivej report, export pokracuje dal.
- Pokud selze autentizace, beh se ukonci.
- Pokud selze XLSX, raw CSV a metadata zustanou ulozene.
- Prioritni report `search_terms` je v pripade chyby vyrazne oznacen v `errors.json` i v `Summary` listu.

## Dulezite poznamky

- `change_history` v Google Ads API vyzaduje datumove okno uvnitr poslednich 30 dni a `LIMIT <= 10000`, proto je tenhle report ve v1 automaticky omezen na poslednich 30 dni bez ohledu na sirsi hlavni exportni rozsah.
- Nektera pole mohou byt v konkretnim uctu nebo typu kampani nedostupna. Exporter se u nepovinnych poli pokusi o fallback a doplni prazdne hodnoty misto padu celeho exportu.
- Lokacni report ve v1 preferuje stabilitu exportu; pokud API nevrati citelne nazvy lokaci, zustanou v reportu identifikatory nebo resource names.
- Merchant Center modul je volitelny. Pokud chybi Merchant scope nebo pristup k uctu, Google Ads export pokracuje dal a Merchant reporty zustanou prazdne s varovanim.
- Pro Merchant API je potreba OAuth refresh token se scope `https://www.googleapis.com/auth/content`.
- GA4 modul je taky volitelny. Bez pristupu do GA4 property Ads export pokracuje dal a GA4 listy zustanou prazdne s varovanim.
- Pro GA4 je potreba OAuth refresh token se scope `https://www.googleapis.com/auth/analytics.readonly`.
- Search Console modul je volitelny. Bez pristupu do property Ads export pokracuje dal a GSC listy zustanou prazdne s varovanim.
- Pro Search Console je potreba OAuth refresh token se scope `https://www.googleapis.com/auth/webmasters.readonly`.
- Search Console dotazy pouzivaji lokalni cache, aby se zbytecne neopakovaly drazsi kombinace `page + query`.
- GTM modul je volitelny. Bez pristupu do GTM accountu nebo containeru Ads export pokracuje dal a GTM listy zustanou prazdne s varovanim.
- Pro GTM je potreba OAuth refresh token se scope `https://www.googleapis.com/auth/tagmanager.readonly`.
- GTM modul pouze cte tagy, triggery, promenne a verze. Nepublikuje ani neupravuje zadne zmeny.
- PageSpeed modul je volitelny. Bezi jen nad top landing pages podle spendu a vysledky cacheuje lokalne podle URL + strategie.
- API key je volitelny, ale bez nej muze byt modul vice omezeny kvotami.
- Pokud `config.accounts.yaml` neexistuje nebo neobsahuje zadne kontexty, aplikace se chova jako puvodni single-account exporter.
- Multi-context exporty bezi sekvencne, aby se snizilo riziko rate limitu.
- Cross-account souhrny se skladaji do `_cross_account` slozky a zustavaji read-only.

## Struktura projektu

```text
app/
  main.py
  auth/
  config/
  web/
  google_ads/
    queries/
  export/
  audit/
  utils/
exports/
```
