"""Google Ads reporting helpers."""
