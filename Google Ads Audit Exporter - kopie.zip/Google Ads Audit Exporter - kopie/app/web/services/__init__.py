"""Web-specific service helpers."""
