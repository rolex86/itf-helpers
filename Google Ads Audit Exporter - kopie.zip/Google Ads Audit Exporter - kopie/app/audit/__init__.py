"""Audit helpers."""
